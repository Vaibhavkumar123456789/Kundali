import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const AstrologerForm = () => {
    return (
        <View>
            <Text>AstrologerForm</Text>
        </View>
    )
}

export default AstrologerForm

const styles = StyleSheet.create({})