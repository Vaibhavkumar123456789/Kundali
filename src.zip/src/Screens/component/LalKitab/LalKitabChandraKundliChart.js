import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const LalKitabChandraKundliChart = () => {
  return (
    <View>
      <Text>LalKitabChandraKundliChart</Text>
    </View>
  )
}

export default LalKitabChandraKundliChart

const styles = StyleSheet.create({})