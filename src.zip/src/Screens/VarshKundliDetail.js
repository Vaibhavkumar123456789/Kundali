import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const VarshKundliDetail = () => {
  return (
    <View>
      <Text>VarshKundliDetail</Text>
    </View>
  )
}

export default VarshKundliDetail

const styles = StyleSheet.create({})