export const COLORS = {
    white: '#fff',
    black: '#333333',
    lightgray: '#ADADAD',
    lightblack: '#00000020',
}