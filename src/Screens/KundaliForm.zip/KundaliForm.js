


import { Text, View, StyleSheet, TouchableOpacity, TextInput, Image, Button } from 'react-native';
import React, { useState, useEffect } from 'react';

const KundaliForm = ({ navigation }) => {
    const APIkey = '03b65e5b66ee6cb40a435eafc29b317a';
    const [city, setcity] = useState('')
    const [res, setRes] = useState('')
    const [field, setField] = useState()


    const search = async () => {
        try {
            const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${APIkey}&units=metric`)
            const res = await response.json()
            // alert(JSON.stringify(res, null, 2))
            setRes(res.main)
            setField(res)
        } catch (error) {
            setError('Failed to fetch weather data. Please try again later.');
        }
    }
    return (

        <View style={styles.box}>
            <View style={{ flex: 1 }}>

                <TextInput
                    value={city}
                    onChangeText={(text) => setcity(text)}
                    style={{ textAlign: 'left', fontSize: 20, backgroundColor: 'white', borderRadius: 10, paddingHorizontal: 10, marginHorizontal: 20, marginTop: 12 }}
                    placeholder="Enter city"
                />
                <Text
                    onPress={() => search()}
                    style={{
                        fontSize: 20, textAlign: 'center', marginTop: 25, marginHorizontal: 20, backgroundColor: 'white', borderRadius: 10, paddingVertical: 7,
                    }}>
                    Search
                </Text>

                <Text
                    style={{ textAlign: 'left', fontSize: 20, fontWeight: '700', marginTop: 25, color: 'white', marginLeft: 20 }}>City Name-{field?.name}</Text>
                <Text
                    style={{ textAlign: 'left', fontSize: 20, fontWeight: '700', marginTop: 15, color: 'white', marginLeft: 20 }}>Weather Temperature-{res?.temp}°c</Text>
                {(field &&
                    <Text
                        style={{ textAlign: 'left', fontSize: 20, fontWeight: '700', marginTop: 15, color: 'white', marginLeft: 20 }}>Weather Description-{field?.weather[0]?.description}</Text>

                )}
                <View style={styles.box1}>

                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 15 }}>
                        <Text style={{ textAlign: 'left', fontSize: 17, fontWeight: '700', marginLeft: 10 }}> Temp:{`\n`} {res?.temp}°c</Text>
                        <Text style={{ textAlign: 'center', fontSize: 17, fontWeight: '700', marginLeft: 25 }}>Feels_like:{`\n`} {res?.feels_like}</Text>
                        <Text style={{ textAlign: 'right', fontSize: 17, fontWeight: '700', marginRight: 10 }}>Temp_min:{`\n`} {res?.temp_min}°c</Text>
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 15 }}>
                        <Text style={{ textAlign: 'left', fontSize: 17, fontWeight: '700', marginLeft: 10 }}> Temp_max:{`\n`} {res?.temp_max}°c</Text>
                        <Text style={{ textAlign: 'center', fontSize: 17, fontWeight: '700', marginRight: 20 }}>Pressure:{`\n`} {res?.pressure}</Text>
                        <Text style={{ textAlign: 'right', fontSize: 17, fontWeight: '700', marginRight: 10 }}>humidity:{`\n`} {res?.humidity}%</Text>
                    </View>

                </View>
            </View>

        </View>


    );
};
export default KundaliForm;
const styles = StyleSheet.create({
    box: {
        width: '100%',
        height: '100%',
        backgroundColor: 'gray',
    },
    box1: {
        width: '90%',
        height: '17%',
        backgroundColor: 'white',
        marginHorizontal: 20,
        marginTop: 20,
        borderRadius: 10,
    },

});

